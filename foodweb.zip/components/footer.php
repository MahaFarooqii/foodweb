<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>our email</h3>
         <a href="mailto:yumyum@gmail.com">yumyum@gmail.com</a>
         <a href="mailto:yum@gmail.com">yum@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>opening hours</h3>
         <p>00:07am to 00:10pm</p>
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>our address</h3>
         <a href="#">Islamabad, Pakistan - 400104</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>our number</h3>
         <a href="tel:0514843801">051-4843801</a>
         <a href="tel:03335136785">0333-5136785</a>
      </div>

   </section>

   
</footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>