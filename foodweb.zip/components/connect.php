<?php

$db_name = 'mysql:host=awseb-e-mfvzr6fnid-stack-awsebrdsdatabase-cddbppgmbh3l.c91ctrvqeyks.ap-south-1.rds.amazonaws.com;dbname=ebdb';
$user_name = 'root';
$user_password = 'Root123$';

$conn = new PDO($db_name, $user_name, $user_password);

?>